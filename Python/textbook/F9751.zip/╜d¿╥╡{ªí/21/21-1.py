def take_attendance(classroom, who_is_here):
    """
    classroom, tuple
    who_is_here, tuple
    Checks if every item in classroom is in who_is_here
    And prints their name if so.
    Returns "finished taking attendance"
    """
    for kid in classroom:
        if kid in who_is_here:
            print(kid)   
    return "finished taking attendance"
