def get_word_length(word1, word2): 
    word = word1+word2  
    return len(word) 
    print("this never gets printed") 
