def say_name(kid):
    print(kid)
def show_kid(kid):
    return kid
say_name("Dora")
show_kid("Ellie")
print(say_name("Frank"))
print(show_kid("Gus"))
