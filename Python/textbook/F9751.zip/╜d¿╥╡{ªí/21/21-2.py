def hello():
    print('Hello!')

hello()
def sayHi(name, title):
    print(name + title +' 你好!')
sayHi(' 王小明 ', ' 同學 ')
