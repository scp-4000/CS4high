def take_attendance(classroom, who_is_here):
    """
    classroom, tuple of strings
    who_is_here, tuple of strings
    Prints the names of all kids in class who are also in who_is_here
    Returns a string, "finished taking attendance"
    """
    for kid in classroom:
        if kid in who_is_here:
            print(kid)
    return "finished taking attendance"
help(take_attendance)
