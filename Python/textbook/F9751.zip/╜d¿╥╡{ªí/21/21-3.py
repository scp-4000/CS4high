sayHi(' 王小明 ', title=' 同學 ')
sayHi(title=' 同學 ', name=' 王小明 ')
sayHi(title=' 同學 ', ' 王小明 ')

 
