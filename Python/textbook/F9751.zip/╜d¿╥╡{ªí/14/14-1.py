Num=int(input("please pick a number: "))
if Num%2==0:
    print("Even Number")
else:
    print("Odd Number")
