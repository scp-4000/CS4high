num_a = int(input("pick a number: "))
num_b = int(input("pick another number: "))
lucky_num = 7
if num_a == num_b:
    print("You enter the same number")
elif num_a > 0 and num_b > 0:
    print("both numbers are positive")
elif num_a < 0 and num_b < 0:
    print("both numbers are negative")
else:
    print("numbers have opposite sign")
if num_a == lucky_num or num_b == lucky_num:
    print("you also guessed my lucky number!")
else:
    print("I have a secret number in mind...")
