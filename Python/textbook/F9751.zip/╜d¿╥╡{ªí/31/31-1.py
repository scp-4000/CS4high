class Rectangle:
    """
    a rectangle object with a length and a width
    """
    def __init__(self, length, width):
        self.length = length
        self.width = width
    def set_length(self, length):
        self.length = length
    def set_width(self, width):
        self.width = width
