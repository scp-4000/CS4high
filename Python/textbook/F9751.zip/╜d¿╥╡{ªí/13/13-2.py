num_a = int(input("Pick a number: "))   
if num_a > 0:
    print("Your number is positive")   
if num_a < 0:
    print("Your number is negative ") 
if num_a == 0: 
    print("Your number is zero")
print("Finished!")
