price = float(input("How much does a chocolate bar cost? "))
hungry = input("Are you hungry(yes or no)? ")

bars = 0
if hungry == "yes": 
    if price < 10:
        print("Buy all chocolate bars.")
        bar = 100
    if 10 <= price <= 50:
        print("Buy 10 chocolate bars.")     
        bars = 10
    if price > 50:
        print("Buy only one chocolate bar.")
        bars = 1
if hungry == "no":
    print("Stick to the shopping list.")
if bars > 10:
    print("Cashier says: someone's hungry!")
