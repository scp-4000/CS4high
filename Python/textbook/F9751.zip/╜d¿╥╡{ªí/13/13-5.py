num_a = int(input("pick a number:"))
num_b = int(input("pick a number:"))
if num_a < 0 and num_b < 0: 
    print("both negative")
