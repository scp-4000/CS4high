num = int(input("Enter a number: "))
if num > 0:
    print("num is positive")
print("finished comparing num to 0") 
