num_a = int(input("Number? "))
num_b = int(input("Number? "))
if num_a < 0:
   print("num_a is negative") 
if num_b < 0:
    print("num_b is negative")
print("Finished")
