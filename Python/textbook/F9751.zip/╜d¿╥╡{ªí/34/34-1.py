import math 
distance = float(input("How far away is your friend?(m)"))
speed = float(input("How fast can you throw?(m/s)"))
angle_d = float(input("What angle do you want to throw at?(degrees)"))
tolerance = 2 
angle_r = math.radians(angle_d)
reach = 2*speed**2*math.sin(angle_r)*math.cos(angle_r)/9.8
if (reach > distance - tolerance)and (reach < distance + tolerance):
    print("Nice throw!")
elif reach < distance - tolerance:
    print("You didn't throw far enough.")
else:
    print("You threw too far.")
