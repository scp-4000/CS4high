import random
choice = input("Choose rock, paper, or scissors: ")
r = random.random()
if r < 1/3:
    print("Computer chose rock.")
    if choice == "paper":
        print("You win!")
    elif choice == "scissors":
        print("You lose.")
    else:
        print("Tie.")
elif 1/3 <= r < 2/3:
    print("Computer chose paper.")
    if choice == "scissors":
        print("You win!")
    elif choice == "rock":
        print("You lose.")
    else:
        print("Tie.")
else: 
    print("Computer chose scissors.")
    if choice == "rock":
        print("You win!")
    elif choice == "paper":
        print("You lose.")
    else:
        print("Tie.")
