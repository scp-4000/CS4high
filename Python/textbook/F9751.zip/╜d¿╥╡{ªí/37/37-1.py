import unittest
class TestMyCode(unittest.TestCase):
    def test_addition_2_2(self):
        self.assertEqual(2+2, 4)
    def test_subtraction_2_2(self):
        self.assertNotEqual(2-2, 4)
unittest.main()
