first3letters = []
first3letters.append("a")
first3letters.append("c")
first3letters.insert(1, "b")
print(first3letters)
last3letters = ["x", "y", "z"]
first3letters.extend(last3letters)
print(first3letters)
last3letters.extend(first3letters)
print(last3letters)
