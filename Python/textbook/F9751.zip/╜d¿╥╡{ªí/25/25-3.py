polite = ["please", "and", "thank", "you"]   
print(polite.pop())
print(polite)
print(polite.pop(1)) 
print(polite)
