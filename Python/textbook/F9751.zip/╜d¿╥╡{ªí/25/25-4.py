colors = ["red", "blue", "yellow"]
colors[0] = "orange"
print(colors)
colors[1] = "green"
print(colors)
colors[2] = "purple"
print(colors)
