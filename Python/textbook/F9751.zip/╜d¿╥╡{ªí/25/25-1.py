years = [1984, 1986, 1988, 1988]
print(len(years))
print(years.count(1988))
print(years.count(2017))
print(years.index(1986))
print(years.index(1988))
