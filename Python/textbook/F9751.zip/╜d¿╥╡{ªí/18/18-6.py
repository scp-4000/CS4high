winners =((" 頭獎 ", "Peter"),(" 二獎 ", "Mark"),(" 三獎 ", "Joy"))
print(" 恭喜以下獎人:")
for prize, winner in winners:
    print(prize+ ":" + winner) 
