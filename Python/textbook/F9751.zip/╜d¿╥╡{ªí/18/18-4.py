prizes =(" 頭獎 ", " 二獎 ", " 三獎 ")
winners =("Peter", "Mark", "Joy")
print(" 恭喜以下得獎人:")
for i in range(3):
    print(prizes[i]+ ":" + winners[i]) 
