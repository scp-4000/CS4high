for x in range(3):
    print("var x is", x)
