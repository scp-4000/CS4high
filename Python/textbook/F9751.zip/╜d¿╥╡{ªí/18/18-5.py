winners =((" 頭獎 ", "Peter"),(" 二獎 ", "Mark"),(" 三獎 ", "Joy"))
print(" 恭喜以下得獎人:")
for e in winners: 
    print(e[0]+ ":" + e[1])
