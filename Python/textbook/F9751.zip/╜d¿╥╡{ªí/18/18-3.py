winners =("Peter", "Mark", "Joy")
print(" 恭喜以下得獎人:")
for name in winners:
    print(name)
