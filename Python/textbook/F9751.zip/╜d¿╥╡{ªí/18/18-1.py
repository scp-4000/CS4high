for ch in "Python is fun!":
    print("the character is", ch) 
