x = 0
while x < 3:
    print("var x is", x)
    x += 1
