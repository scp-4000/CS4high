my_string = "Python is fun!"
len_s = len(my_string)
for i in range(len_s):
    print("the character is", my_string[i]) 
