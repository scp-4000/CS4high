def calculate_similarity(dict1, dict2):
    """
    dict1: frequency dictionary for one text
    dict2: frequency dictionary for another text
    returns: float, representing how similar both texts are toeach other
    """
    diff = 0
    total = 0
    for word in dict1.keys():
        if word in dict2.keys():
            diff += abs(dict1[word] - dict2[word])
        else:
            diff += dict1[word]

    for word in dict2.keys():
        if word not in dict1.keys():   
            diff += dict2[word]
    total = sum(dict1.values()) + sum(dict2.values())
    difference = diff / total
    similar = 1.0– difference
    return round(similar, 2)
