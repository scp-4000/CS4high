import string
def find_words(text):
    """
    text: string
    returns: list of words from input text
    """
    text = text.replace("\n", " ")
    for char in string.punctuation:   
        text = text.replace(char, "")   
     words = text.split(" ")
     return words 
words = find_words(text)
