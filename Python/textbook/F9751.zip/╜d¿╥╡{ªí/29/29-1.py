def read_text(filename):
    """
    filename: string, name of file to read
    returns: string, contains all file contents
    """
    inFile = open(filename)
    line = inFile.read()
    inFile.close()
    return line
text = read_text("sonnet18.txt")
print(text)
