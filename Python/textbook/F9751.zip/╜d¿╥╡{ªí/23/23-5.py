def get_unique_area_codes():
    """
    Returns a tuple of all unique area codes in phones
    """
    area_codes =()
    for ph in phones: 
        if ph[0:3] not in area_codes:  
            area_codes +=(ph[0:3], )   
    return area_codes
