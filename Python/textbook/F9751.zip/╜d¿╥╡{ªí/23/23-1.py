word = "bird\n"
print(word) 
word = word.replace("\n", "") 
print(word)
