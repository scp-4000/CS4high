def sanitize(some_tuple):
    """
    phones, a tuple of strings
    Removes all spaces, dashes, and open/closed parentheses
    in each string
    Returns a tuple with cleaned up string elements
    """
    clean_string =() 
    for st in some_tuple:
        st = st.replace(" ", "")
        st = st.replace("-", "")
        st = st.replace("(", "")
        st = st.replace(")", "")
        clean_string +=(st, ) 
    return clean_string
