def get_states(some_areacodes):
    """
    some_areacodes, a tuple of area codes
    Returns a tuple of the states associated with those areacodes
    """
    states =()
    for ac in some_areacodes:
        if ac not in all_areacodes: states +=("BAD AREACODE", )
        else:
            index = all_areacodes.index(ac)
            states +=(all_places[index], )
    return states
