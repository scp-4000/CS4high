def analyze_friends(names, phones, all_areacodes, all_places):
    """
    names, a tuple of friend names
    phones, a tuple of phone numbers without special symbols
    all_areacodes, a tuple of strings for the area codes
    all_places, a tuple of strings for the US states
    Prints out how many friends you have and every unique
    state that is represented by their phone numbers.
    """
def get_unique_area_codes():
    """
    Returns a tuple of all unique area codes in phones
    """
    area_codes =()
    for ph in phones:
        if ph[0:3] not in area_codes: area_codes +=(ph[0:3], )
    return area_codes

def get_states(some_areacodes):
    """
    some_area_codes, a tuple of area codes
    Returns a tuple of the states associated with those
    area codes
    """
    states =()
    for ac in some_areacodes:
        if ac not in all_areacodes:
            states +=("BAD AREACODE", )
    else:
        index = all_areacodes.index(ac)
        states +=(all_places[index], )
    return states
num_friends = len(names)
unique_area_codes = get_unique_area_codes()
unique_states = get_states(unique_area_codes)
print("You have", num_friends, "friends!")
print("They live in", unique_states)
