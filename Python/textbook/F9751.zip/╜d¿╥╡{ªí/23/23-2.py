def read_file(file):
    """
    file, a file object
    Starting from the first line, it reads every
    2 lines and stores them in a tuple.
    Starting from the second line, it reads every
    2 lines and stores them in a tuple.
    Returns a tuple of the two tuples.
    """
    first_every_2 =()
    second_every_2 =()
    line_count = 1   
    for line in file:   
        stripped_line = line.replace("\n","")
        if line_count%2 == 1:   
            first_every_2 +=(stripped_line,)
        elif line_count%2 == 0:   
            second_every_2 +=(stripped_line,)
        line_count += 1 
    return(first_every_2, second_every_2) 
