def add_word(d, word, definition):
    """ d, dict that maps strings to lists of strings
        word, a string
        definition, a string
        Mutates d by adding the entry word:definition
        If word is already in d, append definition to word’s value list
        Does not return anything
     """
    if word in d:
        d[word].append(definition)
    else:
        d[word] = [definition]

words = {}
add_word(words, 'box', 'fight') 
print(words)
add_word(words, 'box', 'container')
print(words)
add_word(words, 'ox', 'animal') 
print(words)

