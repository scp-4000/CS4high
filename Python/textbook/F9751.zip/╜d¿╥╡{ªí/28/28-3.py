songs = [1, 1, 5, 4]
for s in songs:
    if s == 1: songs.pop(s)
print(songs)
