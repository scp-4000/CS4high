songs = [1, 1, 5, 4]
songs_copy = songs.copy() 
songs = []
for s in songs_copy:     
    if s != 1:
        songs.append(s) 
print(songs)
