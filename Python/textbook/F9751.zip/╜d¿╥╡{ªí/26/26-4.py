stack = []
cook = ['b', 'b', 'b']
stack.extend(cook)
stack.pop()
stack.pop()
cook = ['c', 'c']
stack.extend(cook)
stack.pop()
cook = ['b', 'b']
stack.extend(cook)
stack.pop()
stack.pop()
stack.pop()
