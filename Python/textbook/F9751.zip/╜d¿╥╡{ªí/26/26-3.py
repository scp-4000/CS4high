x = 'x' 
o = 'o'
e = '_'
board = [[x, e, o], [e, x, o], [x, e, e]]

