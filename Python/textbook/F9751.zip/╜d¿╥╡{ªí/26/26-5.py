line = []
line.append('Ana')
line.append('Bob')
line.pop(0)
line.append('Claire')
line.append('Dave')
line.pop(0)
line.pop(0)
line.pop(0)
