heights = [1.4, 1.3, 1.5, 2, 1.4, 1.5, 1]

heights.reverse()  
print(heights)

heights.sort()  
print(heights)

heights.reverse()
print(heights)
