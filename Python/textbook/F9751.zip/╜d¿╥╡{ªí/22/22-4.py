def g():
    print(v+x)  
v= 1
x= 2
g()
