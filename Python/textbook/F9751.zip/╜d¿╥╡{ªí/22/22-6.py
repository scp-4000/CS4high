def odd_or_even(num):
    num = num%2
    if num == 1:
        return "odd"
    else:
        return "even"
num = 4 
print(odd_or_even(num))   
odd_or_even(5)
