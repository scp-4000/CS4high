def h():
    v += 5   
v= 1
h()