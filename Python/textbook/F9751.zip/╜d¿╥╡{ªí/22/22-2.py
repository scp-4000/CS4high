def e():
    v = 5
    print(v)   
v= 1
e()
