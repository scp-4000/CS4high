def fairy_tale():   
    peter = 5
    print(peter)   
peter = 30
fairy_tale()
print(peter)
