def f():
    print(v)
v= 1
f()
