def sandwich(kind_of_sandwich):
    print("--------")
    print(kind_of_sandwich())
    print("--------")
def blt():
    my_blt = " bacon\n lettuce\n tomato"
    return my_blt
def breakfast():
    my_ec = " eggegg\n cheese"
    return my_ec
print(sandwich(blt))
