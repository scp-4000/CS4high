def sing():
    def stop(line):
        print("STOP", line)
    stop("it's hammer time")
    stop("in the name of love")
    stop("hey, what’s that sound")
sing()
stop()
    
