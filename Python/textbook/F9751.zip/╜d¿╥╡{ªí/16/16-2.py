lucky_num = 77
guess = int(input("Guess a Number(0-99): "))
tries = 1
while guess != lucky_num:
    print("You tried to guess", tries, "times")
    guess = int(input("Guess again: "))
    tries += 1
print("You got it!")
