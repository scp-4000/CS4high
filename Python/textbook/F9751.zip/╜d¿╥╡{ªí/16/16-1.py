s = input(" 請輸入顯示內容 : ")
n = int(input(" 請輸入顯示次數 : "))
while n > 0:
    print(s)
    n = n-1
