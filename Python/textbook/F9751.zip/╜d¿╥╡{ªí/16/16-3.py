secret = "code"
max_tries = 100
guess = input("Guess a word: ")
tries = 1
while guess != secret:
    print("You tried to guess", tries, "times")
    if tries == max_tries:
        print("You ran out of tries.")
        break
    guess = input("Guess again: ")
    tries += 1
if tries <= max_tries and guess == secret:
    print("You got it!")
