s = "" 
while s != "喵喵":
    if s != "":
        print(" 不對喔!")
    s = input(" 請輸入通關密語:")
    if s == "out":
        break
else: 
    print(" 恭喜你過關了 ")
print(" 再見!")


