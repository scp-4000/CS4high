words = """art
hue
ink
...
crosshatching
"""
tiles = "hijklmnop"
all_valid_words =()
start = 0
end = 0
found_words =()   
