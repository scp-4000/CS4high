def handle_key(event):
    if event.char == 'w' :
        player1.move('u')
    if event.char == 's' :
        player1.move('d')
    if event.char == 'a' :
        player1.move('l')
    if event.char == 'd' :
        player1.move('r')
    if event.char == 'i' :
        player2.move('u')
    if event.char == 'k' :
        player2.move('d')
    if event.char == 'j' :
        player2.move('l')
    if event.char == 'l' :
        player2.move('r')
