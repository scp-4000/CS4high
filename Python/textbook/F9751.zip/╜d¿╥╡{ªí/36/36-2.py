import random
class Player():
    def __init__(self, canvas, color):
        side = random.randint(1, 100)
        x1 = random.randint(0, 700)
        y1 = random.randint(0, 700)
        x2 = x1+side
        y2 = y1+side
        self.color = color
        self.coords = [x1, y1, x2, y2]
        self.piece = canvas.create_rectangle(self.coords,fill= self.color)
