print("Welcome to the Mashup Game!")
name1 = input("Enter one full name(FIRST LAST): ")
name2 = input("Enter another full name(FIRST LAST): ")

space = name1.find(" ") 
name1_first = name1[0:space]
name1_last = name1[space+1:len(name1)]
space = name2.find(" ")
name2_first = name2[0:space]
name2_last = name2[space+1:len(name2)]

print(name1_first)
print(name1_last)
print(name2_first)
print(name2_last)
