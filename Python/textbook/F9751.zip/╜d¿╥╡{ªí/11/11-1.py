print("Welcome to the Mashup Game!")
name1 = input("Enter one full name(FIRST LAST): ")
name2 = input("Enter another full name(FIRST LAST): ")
 
