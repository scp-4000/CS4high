class Player:
    """ 玩家 """
    def __init__(self, name):
        """ 指定玩家姓名並生成空串列 """
        self.hand = []
        self.name = name
    def get_name(self):
        """ 回傳玩家姓名 """
        return self.name

    def add_card_to_hand(self, card):
        if card != None:
            self.hand.append(card)
    def remove_card_from_hand(self, card):     
        self.hand.remove(card)
    def hand_size(self): 
        return len(self.hand)
