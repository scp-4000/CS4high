class Player:
    """ 玩家 """
    def __init__(self, name):
        """ 指定玩家姓名並生成空串列 """
        self.hand = []
        self.name = name
def get_name(self):
    """ 回傳玩家姓名 """
    return self.name
