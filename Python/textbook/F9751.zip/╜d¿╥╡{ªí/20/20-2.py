a= 1
b= 2
print(a+b)
print(a-b)
print(a*b)
print(a/b)
a= 3
b= 4
print(a+b)
print(a-b)
print(a*b)
print(a/b)
a= 5
b= 6
print(a+b)
print(a-b)
print(a*b)
print(a/b)
