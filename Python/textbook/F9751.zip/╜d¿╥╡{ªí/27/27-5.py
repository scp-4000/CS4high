def square(x):
    return x*x

def circle(r):
    return 3.14*r*r

def equilateraltriangle(s):
    return(s*s)*(3**0.5)/4

areas = {"sq": square, "ci": circle, "eqtri":
         equilateraltriangle}
n= 2
print(areas["sq"](n))
print(areas["ci"](n))
print(areas["eqtri"](n))
