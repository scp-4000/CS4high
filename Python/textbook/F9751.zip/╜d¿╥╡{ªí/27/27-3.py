grades = {}
grades["Chris"] = [100, 70]
grades["Angela"] = [90, 100]
grades["Bruce"] = [80, 40]
grades["Stacey"] = [70, 70]
for student in grades.keys():
    print(student)
for quizzes in grades.values():
    print(sum(quizzes)/2)
for student in grades.keys():
    scores = grades[student]
    grades[student].append(sum(scores)/2)
print(grades)
