legs = {} 
legs["human"] = 2
legs["cat"] = 4
legs["snake"] = 0
print(len(legs))
legs["cat"] = 3
print(len(legs))
print(legs)
