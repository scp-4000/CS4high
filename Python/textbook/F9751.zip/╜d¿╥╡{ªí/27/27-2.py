household = {"person":4, "cat":2, "dog":1, "fish":2}
removed = household.pop("fish")
print(removed)
