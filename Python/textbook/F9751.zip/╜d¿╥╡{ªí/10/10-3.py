input("Where do you live? ")
print("I live in Boston. ")
