for i in range(10, 1, -1):
    print(i, end=" ")
print()
for i in range(0, 9, 2): 
    print(i, end=" ") 
