num = int(input("Please specify the range(0~N): "))
for i in range(2, num+1):   
    for j in range(2, i):
        if(i%j == 0): 
            break 
    else: 
        print(i)
