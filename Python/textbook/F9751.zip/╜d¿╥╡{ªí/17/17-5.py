for i in range(1, 20):
    if i == 5:
        continue
    print(i, end=" ")
    if i == 10:
        break
print("END")
